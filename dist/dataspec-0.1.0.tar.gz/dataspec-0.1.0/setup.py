# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['dataspec']
install_requires = \
['argparse>=1.4.0,<2.0.0',
 'pathlib>=1.0.1,<2.0.0',
 'requests>=2.24.0,<3.0.0',
 'typing>=3.7.4,<4.0.0']

entry_points = \
{'console_scripts': ['data-spec-author = dataspec.bin.dataspec_author:run',
                     'data-spec-retrieve = dataspec.bin.dataspec_retrieve:run']}

setup_kwargs = {
    'name': 'dataspec',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Max G',
    'author_email': 'mvgomov@ucdavis.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
