import argparse
import copy
import ftplib
import json
import logging
import math
import os
import pprint
import sys
import time
import zipfile
from collections import deque, namedtuple
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
from glob import glob
from os.path import (abspath, basename, dirname, exists, getsize, isdir,
                     isfile, join)
from pathlib import Path
from pdb import set_trace as bp
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
from urllib.parse import urlparse

import requests

logging.basicConfig(level=logging.INFO)

# not a useful def here
# class DatasetType(str, Enum):
#     ARCHIVE="ARCHIVE",
#     LIVE="LIVE",
#     ONGOING="ONGOING"

# self-explanatory; various types of file formats
class FileFormat(str, Enum):

    # zipfiles will have a corresponding 'unzip' attribute, specifying the decompressed directory name
    ZIP = ("ZIP",)
    CSV = ("CSV",)
    GEOJSON = ("GEOJSON",)
    JSON = ("JSON",)
    ARCGRID = ("ARCGRID",)
    SHAPEFILE = ("SHAPEFILE",)
    KML = ("KML",)


# file retrieval method
class RetrieveType(str, Enum):

    # standard GET request; source is a url (files only)
    GET = ("GET",)

    # FTP server request; source is an ftp url (directories or files)
    FTP = ("FTP",)

    # manually-populated (i.e. "by hand") data or directory (e.g. for an unscriptable archive source)
    MANUAL = ("MANUAL",)

    # not retrieved; instead, created as part of the defined hierarchy (for directories; files will always be retrieved)
    NONE = ("NONE",)


# object lifecycle or creation scope; different creation scopes will be retrieved in different contexts
class CreateType(str, Enum):

    # statically-created, should always exist, & will be retrieved in a static data pull
    STATIC = ("STATIC",)

    # generated in some way, typically for live data sources (& typically is templated, e.g. via datetime); will not be retrieved in a static data pull, should be handled in a cron-style ETL stage instead
    DYNAMIC = ("DYNAMIC",)


# for figuring out directory types when unmarshalling JSON
class DirectoryType(str, Enum):

    # locally-created directory
    LOCAL = ("LOCAL",)

    # directory retrieved from elsewhere (e.g. via FTP)
    REMOTE = ("REMOTE",)


# necessary?
# class DataRetrieveSpecType(str, Enum):
#     DATASOURCE,
#     DATASET,
#     DIRECTORY,
#     FTP_DIRECTORY,
#     FILE,


class Traversable:
    def traverse(
        self, traverse_stack: deque, match_case: bool = False
    ) -> Optional["DatasetType"]:
        pass


class Downloadable:
    def download(
        self,
        parent_dir: Path,
        level: int = 0,
        validate_existing: bool = True,
        reload_unconfirmable: bool = True,
    ) -> bool:
        pass


class TemplateType(str, Enum):
    DATETIME = "DATETIME"


def datasource_repr(self):
    return pprint.pformat(self._asdict(), indent=1)


def check_dict(key: str, d: Dict[str, Any], match_case: bool = False) -> Optional[Any]:
    dict_set = {k.lower() if not match_case else k: k for k in d}

    check = dict_set.get(key)

    if check is not None:
        return d.get(check)

    return None


# these dataclass definitions also define the layout of the input datasource JSON files
@dataclass
class File(Traversable, Downloadable):
    name: str
    file_type: FileFormat
    retrieve_type: RetrieveType
    source: Optional[str]
    path_name: Path
    description: Optional[str]
    unzip: Optional[Path]
    create_type: CreateType
    retrieve: bool
    retain: bool
    template_types: Optional[List[TemplateType]]

    parent: "Directory"

    # No traversal precedence (no nested structures here)
    def traverse(
        self, traverse_stack: deque, match_case: bool = False
    ) -> Optional["DatasetType"]:
        return self

    def download(
        self,
        parent_dir: Path,
        level: int = 0,
        validate_existing: bool = True,
        reload_unconfirmable: bool = True,
    ) -> bool:
        # downloads a file from the file spec into the file dictated by parent_dir + file_spec.path_name
        # returns True if a valid file is believed to exist, False otherwise
        # def download_file(
        #     parent_dir: Path,
        #     file_spec: File,
        #     level: int = 0,
        #     check_exist: bool = True,
        #     validate_existing_file: bool = True,
        #     reload_unconfirmable: bool = False,
        # ) -> bool:
        # logging.info("Downloading file \"{}\"".format('\t' * level, file_spec.path_name))

        level_info('Downloading file "{}"'.format(self.path_name), level)

        if self.retrieve_type == RetrieveType.GET:
            level_info("GET {}".format(self.source), level)

            if self.source is None or len(self.source) == 0:
                level_info("No source specified; skipping file spec", level)
                return False

            # make the directories leading up to this file, if they don't already exist
            os.makedirs(parent_dir, exist_ok=True)

            file_path = Path(join(parent_dir, self.path_name))

            # request the headers here, with the accepted compression to be 'none' (so that chunking size lines up with content-length here)
            head = requests.head(
                self.source, stream=True, headers={"Accept-Encoding": "identity"}
            )

            # check if the file already exists
            if validate_existing:

                # TODO
                filesize_remote = None

                (exists, is_valid) = validate_file(
                    file_path, remote_filesize=filesize_remote, level=level
                )

                do_download = check_validation_policy(
                    exists,
                    is_valid,
                    level=level,
                    reload_unconfirmable=reload_unconfirmable,
                )

                if not do_download:
                    if exists:
                        return True
                    else:
                        return False

            level_info("Into {}".format(file_path), level)

            # request the file here; we're going to look at the Content-Length header size and want some fine-grained control over how we download this (e.g. for logging purposes), so enable streaming
            get_chunked(self.source, Path(file_path), level=level)

            return True

        elif self.retrieve_type == RetrieveType.FTP:
            level_info("FTP {}".format(self.source), level)
        if self.retrieve_type == RetrieveType.MANUAL:
            level_info("Manual (no-op)", level)

        # catch-all false, retrieve_type not handled
        level_info('Retrieve type not handled ("{}")'.format(self.retrieve_type), level)
        return False


@dataclass
class Directory(Traversable):
    name: str
    path_name: Path
    create_type: CreateType
    dirs: Dict[str, "Directory"]
    files: Dict[str, File]

    parent: Union["Dataset", "Directory"]

    # Files first
    def traverse(
        self, traverse_stack: deque, match_case: bool = False
    ) -> Optional["DatasetType"]:

        # base case; nothing left in the traversal stack, so this is (hopefully) what we were looking for
        if len(traverse_stack) == 0:
            return self

        target = traverse_stack.popleft()

        have_file = check_dict(target, self.files, match_case=match_case)

        # files can't traverse, so don't try (and if there's still something left in the traverse stack, skip it)
        if have_file and len(traverse_stack) == 0:
            return have_file
        elif len(traverse_stack) > 0:
            # don't try to traverse a file; fail safely and make the user specify
            return None

        have_dir = check_dict(target, self.dirs, match_case=match_case)

        if have_dir:
            return have_dir.traverse(traverse_stack, match_case=match_case)

        return None

    def download(
        self,
        parent_dir: Path,
        level: int = 0,
        validate_existing: bool = True,
        reload_unconfirmable: bool = True,
    ) -> None:
        dir_path = Path(join(parent_dir, self.path_name))

        for subdir_name, subdir in self.dirs.items():
            # download_directory(dir_path, subdir, level=level + 1)
            subdir.download(dir_path, level=level + 1)

        for subfile_name, subfile in self.files.items():
            # download_file(dir_path, subfile, level=level + 1)
            subfile.download(dir_path, level=level + 1)


@dataclass
class RemoteDirectory(Traversable):
    name: str
    path_name: Path
    retrieve_type: RetrieveType
    source: str

    parent: Union["Dataset", Directory]

    def traverse(
        self, traverse_stack: deque, match_case: bool = False
    ) -> Optional["DatasetType"]:

        # base case; nothing left in the traversal stack, so this is (hopefully) what we were looking for
        if len(traverse_stack) == 0:
            return self
        else:
            # can't (yet) request a subfile for a remote directory
            return None

    def download(
        self,
        parent_dir: Path,
        level: int = 0,
        validate_existing: bool = True,
        reload_unconfirmable: bool = True,
    ) -> None:
        # download_remote_directory(dir_path, directory, level=level)
        # def download_remote_directory(
        #     parent_dir: Path,
        #     dir_spec: RemoteDirectory,
        #     level: int = 0,
        #     validate_existing: bool = True,
        #     reload_unconfirmable: bool = True,
        # ) -> None:
        if self.retrieve_type == RetrieveType.GET:
            level_error("Retrieve type GET not impl.; object: {}".format(self), level)
        elif self.retrieve_type == RetrieveType.FTP:
            url = urlparse(self.source)
            level_info(
                "Retrieving directory at {} from path {} into {}".format(
                    url.netloc, url.path, parent_dir
                ),
                level,
            )
            os.makedirs(parent_dir, exist_ok=True)

            with ftplib.FTP(host=url.netloc) as ftp:
                ftp.login()
                level_info("FTP connection successful", level)
                remote_files = ftp.nlst(url.path)

                for remote_file in remote_files:
                    remote_path = Path(remote_file)
                    file_path = Path(join(parent_dir, remote_path.name))

                    level_info("Downloading {}...".format(remote_path.name), level)

                    if validate_existing:
                        remote_size = ftp.size(remote_file)

                        (exists, is_valid) = validate_file(
                            file_path, remote_filesize=remote_size, level=level
                        )

                        do_download = check_validation_policy(
                            exists,
                            is_valid,
                            level=level,
                            reload_unconfirmable=reload_unconfirmable,
                        )

                        if not do_download:
                            continue

                    with open(file_path, "wb") as ftp_file:
                        ftp.retrbinary("RETR {}".format(remote_file), ftp_file.write)

                    level_info(
                        "Finished downloading {} (size {})".format(
                            remote_path.name, convert_size(getsize(file_path))
                        ),
                        level,
                    )

        elif self.retrieve_type == RetrieveType.MANUAL:
            level_error("Retrieve type MANUAL no-op; object: {}".format(self), level)
        elif self.retrieve_type == RetrieveType.NONE:
            level_error("Retrieve type NONE no-op.; object: {}".format(self), level)
        else:
            level_error("Retrieve type unmatched; object: {}".format(self), level)


@dataclass
class Dataset(Traversable):
    name: str
    description: Optional[str]
    org: Directory

    parent: "Datasource"

    def traverse(
        self, traverse_stack: deque, match_case: bool = False
    ) -> Optional["DatasetType"]:

        # forward the traversal to the (org)anization of the dataset (i.e. the dir)
        return self.org.traverse(traverse_stack, match_case=match_case)

    def download(self, parent_dir: str, level: int = 0):
        # def download_dataset(parent_dir: Path, dataset: Dataset, level: int = 1):

        logging.info('{}Downloading dataset "{}"'.format("\t" * level, self.name))

        # used to use the dataset name as a directory name directly, but instead this is specified in the org dir
        # dir_path = join(parent_dir, dataset.name)
        dir_path = parent_dir

        # download_directory(dir_path, dataset.org, level=level + 1)
        self.org.download(dir_path, level=level + 1)


@dataclass
class Datasource(Traversable):
    name: str
    description: Optional[str]
    datasets: Dict[str, Dataset]
    datasources: Dict[str, "Datasource"]

    parent: Optional["Datasource"]

    def traverse(
        self, traverse_stack: deque, match_case: bool = False
    ) -> Optional["DatasetType"]:

        # base case; nothing left in the traversal stack, so this is (hopefully) what we were looking for
        if len(traverse_stack) == 0:
            return self

        target = traverse_stack.popleft()

        # try datasources first
        have_dsource = check_dict(target, self.datasources, match_case=match_case)

        if have_dsource:
            return have_dsource.traverse(traverse_stack)

        # next, datasets

        have_dset = check_dict(target, self.datasets, match_case=match_case)

        if have_dset:
            return have_dset.traverse(traverse_stack, match_case=match_case)

        return None

    def download(self, parent_dir: Path, level: int = 0):
        ds_path = Path(join(parent_dir, self.name))

        logging.info('{}Downloading datasource "{}"'.format("\t" * level, self.name))

        for subsource_name, subsource in self.datasources.items():
            subsource.download(ds_path, subsource, level=level + 1)

        for dataset_name, dataset in self.datasets.items():
            dataset.download(ds_path, dataset, level=level + 1)


DatasetType = Union[Datasource, Dataset, Directory, RemoteDirectory, File]
DataCollection = Dict[str, DatasetType]


def parse_datasource_spec(
    ds_spec: dict, parent: Optional[Datasource]
) -> Optional[Datasource]:
    # ds_copy = Datasource(**copy.deepcopy(ds_spec))
    ds_copy = copy.deepcopy(ds_spec)

    try:
        ds_obj = Datasource(**ds_copy, parent=parent)
    except TypeError as e:
        logging.error(
            "Malformed datasource spec: {}\nObject: {}".format(
                e, pprint.pformat(ds_spec, depth=1, indent=4)
            )
        )

        return None

    datasets = {}
    for subset_name, subset_spec in ds_copy["datasets"].items():
        # ds_copy["datasets"][subset_name] = parse_dataset_spec(subset_spec)
        datasets[subset_name] = parse_dataset_spec(subset_spec, ds_obj)

    ds_obj.datasets = datasets

    datasources = {}
    for subsource_name, subsource_spec in ds_copy["datasources"].items():
        # ds_copy["datasources"][subsource_name] = parse_datasource_spec(subsource_spec)
        datasources[subsource_name] = parse_datasource_spec(subsource_spec, ds_obj)

    ds_obj.datasources = datasources

    return ds_obj


def parse_dataset_spec(ds_spec: dict, parent: Datasource):
    ds_copy = copy.deepcopy(ds_spec)

    try:
        ds_obj = Dataset(**ds_copy, parent=parent)
    except TypeError as e:
        logging.error(
            "Malformed dataset spec: {}\nObject: {}".format(
                e, pprint.pformat(ds_spec, depth=1, indent=4)
            )
        )

        return None

    # ds_copy["org"] = parse_dir_spec(ds_copy["org"])
    ds_obj.org = parse_dir_spec(ds_copy["org"], ds_obj)

    return ds_obj


def parse_dir_spec(
    dir_spec: dict, parent: Union[Dataset, Directory]
) -> Union[None, Directory, RemoteDirectory]:
    ds_copy = copy.deepcopy(dir_spec)

    dir_obj: Union[None, Directory, RemoteDirectory] = None

    try:
        ds_type = DirectoryType(ds_copy["type"])
    except ValueError as e:
        logging.error(
            f"Directory type not specified or invalid (type string: '{ds_copy['type']}')"
        )
        return None

    # if set(ds_copy.keys()) == set(Directory.__annotations__):
    if ds_type == DirectoryType.LOCAL:

        try:
            dir_obj = Directory(**ds_copy, parent=parent)
        except TypeError as e:
            logging.error(
                "Malformed dir spec: {}\nObject: {}".format(
                    e, pprint.pformat(dir_spec, depth=1, indent=4)
                )
            )

            return None

        try:
            # ds_copy["create_type"] = CreateType(ds_copy["create_type"])
            ds_obj.create_type = CreateType(ds_copy["create_type"])
        except ValueError as e:
            print(e)

        dirs = {}
        for subdir_name, subdir in ds_copy["dirs"].items():
            # ds_copy["dirs"][subdir_name] = parse_dir_spec(subdir)
            dirs[subdir_name] = parse_dir_spec(subdir, dir_obj)

        ds_obj.dirs = dirs

        files = {}
        for subfile_name, subfile in ds_copy["files"].items():
            # ds_copy["files"][subfile_name] = parse_file_spec(subfile)
            files[subfile_name] = parse_file_spec(subfile, dir_obj)

        ds_obj.files = files

        return dir_obj

    # elif set(ds_copy.keys()) == set(RemoteDirectory.__annotations__):
    if ds_type == DirectoryType.REMOTE:

        try:
            # ds_copy['create_type']= CreateType(ds_copy['create_type'])
            ds_copy["retrieve_type"] = RetrieveType(ds_copy["retrieve_type"])
        except ValueError as e:
            print(e)

        try:
            dir_obj = RemoteDirectory(**ds_copy, parent=parent)
        except TypeError as e:
            logging.error(
                "Malformed remote dir spec: {}\nObject: {}".format(
                    e, pprint.pformat(dir_spec, depth=1, indent=4)
                )
            )

            return None

        return dir_obj

    else:
        logging.error(
            "Directory spec doesn't match Directory or RemoteDirectory (keys are {})\nObject: {}".format(
                ds_copy.keys(), pprint.pformat(dir_spec, depth=1, indent=4)
            )
        )
        return None


# def download_directory(parent_dir: Path, directory: Directory, level: int = 1) -> None:

#     logging.info(
#         '{}Downloading contents of directory "{}"'.format(
#             "\t" * level, directory.path_name
#         )
#     )

#     dir_path = Path(join(parent_dir, directory.path_name))

#     # either handle as a regular directory, or as a RemoteDirectory
#     if isinstance(directory, Directory):
#     elif isinstance(directory, RemoteDirectory):
#         download_remote_directory(dir_path, directory, level=level)


def parse_file_spec(file_spec: dict, parent: Directory) -> Optional[File]:
    fs_copy = copy.deepcopy(file_spec)

    file_obj: Optional[File] = None

    try:
        file_obj = File(**fs_copy, parent=parent)
    except TypeError as e:
        logging.error(
            "Malformed file spec: {}\nObject: {}".format(
                e, pprint.pformat(file_spec, depth=1, indent=4)
            )
        )

        return None

    try:
        # fs_copy["file_type"] = FileFormat(fs_copy["file_type"])
        # fs_copy["retrieve_type"] = RetrieveType(fs_copy["retrieve_type"])
        # fs_copy["create_type"] = CreateType(fs_copy["create_type"])
        file_obj.file_type = FileFormat(fs_copy["file_type"])
        file_obj.retrieve_type = RetrieveType(fs_copy["retrieve_type"])
        file_obj.create_type = CreateType(fs_copy["create_type"])

    except ValueError as e:
        print(e)

    if fs_copy["retrieve_type"] == RetrieveType.GET:
        url_check = urlparse(fs_copy["source"])
        if len(url_check.scheme) == 0 or len(url_check.netloc) == 0:
            logging.error(
                'Malformed file spec (source missing or invalid, in source "{}")\nObject: {}'.format(
                    fs_copy["source"], pprint.pformat(file_spec, depth=1, indent=4)
                )
            )
            return file_obj

    return file_obj


# from https://stackoverflow.com/questions/5194057/better-way-to-convert-file-sizes-in-python
def convert_size(size_bytes: int) -> str:
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return "%s %s" % (s, size_name[i])


def check_validation_policy(
    exists: bool,
    is_valid: Optional[bool],
    level: int = 0,
    reload_unconfirmable: bool = True,
) -> bool:
    if not exists:
        level_info("File doesn't exist; downloading", level)
        return True

    if exists and is_valid:
        level_info("Skipping download", level)
        return False

    if exists and not is_valid:
        level_info("File exists, but isn't valid", level)
        return True

    if exists and is_valid is None:
        if is_valid is None and reload_unconfirmable is True:
            level_info("Unconfirmable file; downloading", level)
            return True
        elif is_valid is None and reload_unconfirmable is False:
            level_info("Unconfirmable file; skipping (assumed good)", level)
            return False

    level_info(
        "Validation policy not handled (exists? {}; is_valid? {})".format(
            exists, is_valid
        ),
        level,
    )
    return False


def get_filesize_from_headers(
    headers: requests.structures.CaseInsensitiveDict,
    log: bool = True,
    level: int = 0,
) -> Optional[int]:
    def log_level_if(string, level):
        if log:
            level_info(string, level)

    # try to figure out if we can get the uncompressed filesize from the source link; with gzip-encoding, this gives compressed transfer size
    # there's at least one more path, requesting with Accept-Encoding: "" and seeing if the transfer-encoding isn't chunked
    if headers.get("Content-Encoding") in ["gzip", "compress", "deflate", "br"]:
        log_level_if(
            "Content-Encoding (\"{}\") is compressed; can't determine an uncompressed content length & can't validate file".format(
                headers["Content-Encoding"]
            ),
            level,
        )
        return None

    if headers.get("Content-Length") is None:
        log_level_if(
            "Content-Length is unknown; can't determine a content length & can't validate file",
            level,
        )
        return None

    # TODO this probably warrants a bit more careful treatment
    filesize_src = int(headers["Content-Length"])

    return filesize_src


# returns (exists, valid) tuple where exists is a bool and valid is a bool or None for indeterminate/unknown
# def validate_file(headers, file_path, log=True, level=0, validate_size=True):
def validate_file(
    file_path: Path,
    remote_filesize: Optional[int] = None,
    file_hash: Optional[str] = None,
    log: bool = True,
    level: int = 0,
    validate_size: bool = True,
) -> Tuple[bool, Optional[bool]]:
    def log_level_if(string, level):
        if log:
            level_info(string, level)

    if not exists(file_path):
        return (False, False)

    filesize = getsize(file_path)

    if remote_filesize is not None:
        # file size validation logic block; various checks and logs based on function params and local vs. source file sizes
        if filesize == remote_filesize:
            log_level_if(
                "File already exists: {} vs. expected {} (size match; skip retrieve)".format(
                    convert_size(filesize), convert_size(remote_filesize)
                ),
                level,
            )
            return (True, True)
        else:
            log_level_if(
                "File already exists: {} vs. expected {} (mismatch; retrieve from source)".format(
                    convert_size(filesize), convert_size(remote_filesize)
                ),
                level,
            )
            return (True, False)

    else:
        return (True, None)


def get_chunked(
    source_url: str,
    dst_path: Path,
    log: bool = True,
    level: int = 0,
    cp_percent: float = 0.1,
) -> None:
    resp = requests.get(source_url, stream=True)

    # grabbing file size and generating the "size string" (to reuse later, esp. since the no-size logic would clutter later code)
    filesize_src = None
    size_str = "??"
    if resp.headers.get("Content-Length") is not None and resp.headers.get(
        "Content-Encoding"
    ) not in ["gzip", "compress", "deflate", "br"]:
        filesize_src = int(resp.headers.get("Content-Length"))
        size_str = convert_size(filesize_src)
        level_info("File size is {}".format(size_str), level)
    else:
        level_info("File size is unknown", level)

    # 'checkpoint' chunk sizing, for logging purposes (every 10% by default)
    cp_chunk_size = (
        int(cp_percent * filesize_src) if filesize_src is not None else 1024 ** 2 * 100
    )
    cp_chunk_idx = 0

    with open(dst_path, "wb") as out_file:
        chunk_accum = 0
        for chunk in resp.iter_content(chunk_size=1024 ** 2):
            out_file.write(chunk)

            chunk_accum = chunk_accum + len(chunk)

            if cp_chunk_idx * cp_chunk_size < chunk_accum:
                cp_chunk_idx = cp_chunk_idx + 1

                if log:
                    level_info(
                        "{} / {} ({}%)".format(
                            convert_size(chunk_accum),
                            size_str,
                            int(chunk_accum / filesize_src * 100)
                            if filesize_src is not None
                            else "??",
                        ),
                        level,
                    )


def level_info(msg: Any, level: int) -> None:
    level_log(logging.info, msg, level)


def level_error(msg: Any, level: int) -> None:
    level_log(logging.error, msg, level)


def level_log(log_fn: Callable[..., None], msg: Any, level: int = 0) -> None:
    log_fn("{}{}".format("\t" * level, msg))


def parse_datasource_directory(dir: Path) -> dict:
    for root, dirs, files in os.walk(dir):
        pass

    return {}


def parse_datasource_file(file_path: Path) -> Optional[Dict[Any, Optional[Datasource]]]:
    datasources = {}

    if exists(file_path) and isfile(file_path):
        with open(file_path) as ds_file:
            try:
                data_json = json.load(ds_file)
            except json.JSONDecodeError as e:
                logging.error(
                    f"Provided datasource file ({file_path}) is not a JSON file, parse error follows: \n{e}"
                )

                return None

            for name, ds_json in data_json.items():
                ds_spec = parse_datasource_spec(ds_json, None)
                datasources[name] = ds_spec

    else:
        logging.error(
            f'Provided datasource file path does not exist or is not a file: "{file_path}"'
        )
        return None

    return datasources


def process_args(args: argparse.Namespace):

    print(args)

    data_dst_path = Path(args.data_directory)

    datasources = {}

    def join_ds(fp, ds):
        parsed_ds = parse_datasource_file(fp)
        if parsed_ds is not None:
            return {**ds, **parsed_ds}
        else:
            return False

    def apply_args(dst: DatasetType, args: argparse.Namespace):
        if args.validate:
            pass

        if args.download:
            # download(dst, download_types=[])
            dst.download()

    # grab any specified datasources

    # handle datasource_file
    if args.datasource_file is not None:
        ds_file_path = Path(args.datasource_file)
        datasources = join_ds(ds_file_path, datasources)

    # handle datasource dir
    if args.datasource_dir is not None:
        ds_dir_path = Path(args.datasource_dir)

        if exists(ds_dir_path) and isdir(ds_dir_path):
            ds_dir_files = glob(join(ds_dir_path, "*.json"))
            logging.info(f"Found files in provided path: {ds_dir_files}")

            for ds_file_path in ds_dir_files:
                # = parse_datasource_file(ds_path)
                datasources = join_ds(ds_file_path, datasources)

        else:
            logging.error(
                f'Provided datasource file path does not exist or is not a file: "{ds_file_path}"'
            )
            return False

    if args.qualifier:
        retrieved = {}

        for qualifier_arr in args.qualifier:
            have_ret = retrieve_by_qualifier(qualifier_arr[0])
            if have_ret:
                name, ret = have_ret
                retrieved[name] = ret
            # TODO here

        for name, ret in retrieved.items():
            apply_args(ret, args)

    else:
        for name, datasource in datasources.items():
            apply_args(datasource, args)
            # download_datasource(data_dst_path, datasource)

    # run the download code
    # param_path = "../params/landfire.json"
    # param_path = "../params/nifc.json"
    # param_path = "../params/uscb.json"
    # with open(param_path) as df:
    #     data_json = json.load(df)
    #     # ds_spec = parse_datasource_spec(data_json["LANDFIRE"])
    #     # ds_spec = parse_datasource_spec(data_json["NIFC"])
    #     ds_spec = parse_datasource_spec(data_json["USCB"])
    #     bp()
    #     download_datasource("/home/max/dl_test/", ds_spec)
    # bp()


def retrieve_by_qualifier(
    spec: DataCollection, qualifier: str, delimiter: str = ".", match_case: bool = False
) -> Tuple[str, Optional[DatasetType]]:

    qual_parts = qualifier.split(delimiter)
    qual_stack = deque(qual_parts)

    print(qual_parts, qual_stack)

    first = qual_stack.popleft()

    have_first = check_dict(first, spec, match_case=match_case)

    name, retrieved = spec.traverse(qual_stack, match_case=match_case)

    print(name, retrieved)

    return (name, retrieved)


if __name__ == "__main__":
    bp()
    parser = argparse.ArgumentParser(
        description="CLI frontend for describing and downloading datasets."
    )

    parser.add_argument(
        "-dsf",
        "--datasource_file",
        help=" [Optional] Specific datasource file to parse",
        dest="datasource_file",
        type=str,
    )

    parser.add_argument(
        "-dl",
        "--download",
        action="store_true",
        help="Flag; if provided, all specified datasources will be downloaded",
        dest="download",
    )

    parser.add_argument(
        "-v",
        "--validate",
        action="store_true",
        help="Flag; if provided, directories and files will be validated",
        dest="validate",
    )

    parser.add_argument(
        "-p",
        "--print_tree",
        action="store_true",
        help="Flag; if provided, will print the datasource trees after parsing",
        dest="print_tree",
    )

    parser.add_argument(
        "-dsd" "--datasource_dir",
        help="Directory of datasource files to parse (default: current directory). If qualifiers aren't provided, operations will be applied to all datasources in the given directory.",
        type=str,
        default="./",
        dest="datasource_dir",
    )

    parser.add_argument(
        "-ls",
        "--load_static",
        help="Flag; if provided, download static files ",
        action="store_true",
        default=False,
        dest="load_static",
    )

    parser.add_argument(
        "-lsch",
        "--load_scheduled",
        help="Flag; if provided, download scheduled retrieve files",
        action="store_true",
        default=False,
        dest="load_scheduled",
    )

    parser.add_argument(
        "-dd",
        "--data_directory",
        help="Destination directory for downloaded data",
        type=str,
        required=True,
        dest="data_directory",
    )

    parser.add_argument(
        "-q",
        "--qualifier",
        help="Fully qualified identifier for a datasource/dataset/directory/file, case-insensitive and delimited by periods. Multiple qualifiers can be provided, either as a space-delimited list following the argument, or via separate individual arguments. If not provided, all input datasource files will be processed.",
        nargs="*",
        action="append",
        dest="qualifier",
    )

    args = parser.parse_args()
    print(args)
    process_args(args)
